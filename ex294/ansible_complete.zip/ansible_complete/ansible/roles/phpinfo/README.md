Role Name
=========

Role to configure Web Server 

Requirements
------------

Ansible >= 2.8 

Dependencies
------------

Enterprse Linux 

Example Playbook
----------------

    - hosts: servers
      roles:
      - raghav1674.phphello


Author Information
------------------

ragaws1674@gmail.com
