#!/usr/bin/bash


# YES yes true TRUE 1  

ansible all -m yum_repository -a 'file="external" name="Base_OS" baseurl="http://mirror.centos.org/centos/8/BaseOS/x86_64/os/" description="Base Os" enabled=true gpgcheck=true gpgkey="http://mirror.centos.org/centos/RPM-GPG-KEY-CentOS-Official state=present"'


ansible all -m yum_repository -a 'file="external" name="AppStream_OS" baseurl="http://mirror.centos.org/centos/8/AppStream/x86_64/os/" description="AppStream" enabled=true gpgcheck=true gpgkey="http://mirror.centos.org/centos/RPM-GPG-KEY-CentOS-Official state=present"'



